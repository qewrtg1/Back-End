document.write("환영합니다")
// document:출력해라, 'write'써 있는 것을. ()="환영합니다.")
