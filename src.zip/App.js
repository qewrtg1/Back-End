
import './App.css';
import InputSample1 from './InputSample1';
function App(){
  
  return( 
   <InputSample1 />
  );

}
export default App;